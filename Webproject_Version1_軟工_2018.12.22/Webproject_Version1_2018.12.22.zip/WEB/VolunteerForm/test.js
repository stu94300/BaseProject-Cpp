var express = require("express");
var app = express();
const port = 3000;

app.get("/", function (req, res) {
    res.sendFile(__dirname + "/" + "Formal.html");
});



app.get("/process_get", function (req, res) {
    const name = req.query.username;
    const sex = req.query.gender;
    const birth = req.query.bday;
    const ID = req.query.ID;
    const connect = req.query.phone;
    const address = req.query.email;
    const activity = req.query.event;

    res.send(` 姓名: ${name} ` + `<br>` +
        `性別: ${sex} ` + `<br>` +
        `出生年月日: ${birth}` + `<br>`+
        `身分證字號: ${ID} ` + `<br>` +
        `聯絡方式(手機/電話): ${connect}` + `<br>` +
        `E-Mail: ${address}  ` + `<br>` +
        `欲參加的志工服務項目: ${activity}`
    );
});

app.listen(port, () => console.log(`Start Test!`));